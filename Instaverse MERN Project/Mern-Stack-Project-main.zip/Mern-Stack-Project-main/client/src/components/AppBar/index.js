import AppBar from "./AppBar";
import { memo } from "react";

export default memo(AppBar);