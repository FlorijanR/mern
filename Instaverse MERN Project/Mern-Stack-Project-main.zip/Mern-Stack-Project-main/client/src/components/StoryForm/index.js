import StoryForm from "./StoryForm";
import { memo } from "react";

export default memo(StoryForm);