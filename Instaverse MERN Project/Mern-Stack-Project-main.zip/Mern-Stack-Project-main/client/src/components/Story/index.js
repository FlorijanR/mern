import Story from "./Story";
import { memo } from "react";

export default memo(Story);