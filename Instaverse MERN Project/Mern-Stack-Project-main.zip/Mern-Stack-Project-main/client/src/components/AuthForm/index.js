import AuthForm from "./AuthForm";
import { memo } from "react";

export default memo(AuthForm);