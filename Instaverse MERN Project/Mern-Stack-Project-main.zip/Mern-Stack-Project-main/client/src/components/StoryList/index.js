import StoryList from "./StoryList";
import { memo } from "react";

export default memo(StoryList);