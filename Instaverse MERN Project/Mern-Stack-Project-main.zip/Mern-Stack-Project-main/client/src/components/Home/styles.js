const styles = {
    sider:{
        background: '#f0f2f5'
    },
    content:{
        margin:'2rem'
    }
}

export default styles