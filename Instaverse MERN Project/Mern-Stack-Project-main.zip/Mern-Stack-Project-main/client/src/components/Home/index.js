import Home from "./Home";
import { memo } from "react";

export default memo(Home);